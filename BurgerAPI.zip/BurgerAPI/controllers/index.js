module.exports = {
//  BorneController: require('./borne'),
  IngredientController : require('./ingredient'),
  ProduitController : require('./produit'),
  BoissonController : require('./boisson')
};
