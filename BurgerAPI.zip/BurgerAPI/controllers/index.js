module.exports = {

  MenuController: require('./menu'),
  IngredientController : require('./ingredient'),
  ProductController : require('./product'),
  PromotionController : require('./promotion'),
  UserController : require('./user'),
  OrderController : require('./order')
};
